                                                                                                                                                                                                                                                  
$(document).ready(function(){
	login();
	createCustomer();
	add();
	transfer();
	logout();
	edit();
	post("1234", "4567");
	sortTransaction("1234", "4567");
});

var login=function(){
	$('#login').submit(function(e){
		var destination="";
		var user=$("input[name='Username']").val();
		var pass=$("input[name='Password']").val();
		var permission=$('select option:selected').val();
		var c=Setup.database.check(user,pass,permission);
		if(c==1)
			destination="Customer2.html";
		else if(c==2)
			destination="Employee2.html";
		else
			alert("Wrong username or password!");
		window.location=destination;
		return false;
		
	});
};

var post=function(user, pass){
	var e=Setup.database.find(user,pass);
	$(e.transactionList).each(function(i,e){
		var date=e.date.toDateString();
		$('table#data').append("<tr>"+"<td>"+date.slice(date.indexOf(" ")+1)+"</td>"+"<td>"+e.type+"</td>"+"<td>"+e.amount+"</td>"+"</tr>");
		$('table#data tr:nth-child(2n)').css("background-color", "#FFCC33");
	});
	return false;
};

var createCustomer=function(){
	$('#create').submit(function(e){
		var firstName=$("input[name='first']").val();
		var lastName=$("input[name='last']").val();
		var SSN=$("input[name='SSN']").val();
		var DOB=new Date($("input[name='DOB']").val());
		var address=$("input[name='address']").val();
		var account=$("input[name='account']").val();
		var routing=$("input[name='routing']").val();
		var email=$("input[name='email']").val();
		var user=$("input[name='username']").val();
		var pass=$("input[name='password']").val();
		var balance=parseFloat($("input[name='initBalance']").val());
		Setup.database.createCustomer(firstName, lastName, DOB, SSN, email,address, user, pass, balance, account, routing);
		$(Setup.database.customerList).each(function(i,e){
			alert("UserName:" + e.userName + " " + "PassWord:" + " " + e.passWord);
		});
		return false;
	});
};

var add=function(){
	$('#addTransaction').submit(function(e){	
		var account=$("input[name='account']").val();
		var routing=$("input[name='routing']").val();
		var type=$('select option:selected').val();
		var date=new Date($("input[name='day']").val());
		var amount=parseFloat($("input[name='amount']").val());
		Setup.database.addTransaction(amount, type, date, account, routing, 1);
		return false;
	});	
};

var transfer=function(){
	$('#transfer').submit(function(e){
		var account=$("input[name='account number']").val();
		var routing=$("input[name='routing number']").val();
		var amount=parseFloat($("input[name='amount']").val());
		var date=new Date($("input[name='day']").val());
		var user=$("input[name='user']").val();
		var pass=$("input[name='pass']").val();
		Setup.database.transfer(routing, account, user, pass, amount);
		return false;
	});
};

var edit=function(){
	$('#edit').submit(function(e){
		var nuser=$("input[name='newUser']").val();
		var npass=$("input[name='newPass']").val();
		var cnpass=$("input[name='cNewPass']").val();
		var addr=$("input[name='address']").val();
		var ouser=$("input[name='oldUser']").val();
		var opass=$("input[name='oldPass']").val();
		var email=$("input[name='email']").val();
		if(npass!=cnpass)
			alert("Different password");
		Setup.database.editProfile(addr, email, opass, ouser, npass, nuser);
		return false;
	});
};
		
var logout=function(){
	$('#logout').submit(function(e){
		window.location="Login2.html";
		return false;
	});
};

var sortTransaction=function(user, pass){
	$("button[name='sort']").click(function(e){
		var choice=$('select#sort option:selected').val();
		var order=$('select#order option:selected').val();
		$('table#data').empty();
		Setup.database.sortTransaction(user, pass, choice, order);
		post(user, pass);
		return false;
	});	
};
