<?php
	session_destroy();
	header("HTTP/1.1 200 Success");
	exit();
?>
